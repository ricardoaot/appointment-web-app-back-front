interface ICredentialsDto {
    userName: string;
    password: string;    
}

export default ICredentialsDto