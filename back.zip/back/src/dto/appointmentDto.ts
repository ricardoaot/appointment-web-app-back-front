interface IAppointment {
    date: string;
    time: string;
    userId: number;
}

export default IAppointment