interface ICredentials {
    credentialId: number;
    userName: string;
    password: string;
}

export type {ICredentials}