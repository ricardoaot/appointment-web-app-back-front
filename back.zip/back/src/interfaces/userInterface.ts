interface IUser {
    userId: number;
    name: string;
    email: string;
    birthdate: string;
    nDni: string;
    credentialId: number;
}

export default IUser
