import myAppointmentsData from "../helpers/myAppointmentsData"
import Appointment from "../components/Appointment"
import { useEffect, useState } from "react"
import axios from "axios"
import { useDispatch, useSelector } from "react-redux"
import { fetchAppointment } from "../redux/userAppointmentsSlice"

const Appointments = () => {
    const dispatch = useDispatch()
    //const [appointments, setAppointment] = useState([])
    const appointments = useSelector((state) => state.userAppointmentsState)??[]
    const user = useSelector((state) => state.userState)
    console.log(appointments)
    console.log(user)

    useEffect(() => {
        if(user.login){
            axios.get("http://localhost:3000/user/1")
            .then((response) => {
                //setAppointment(response.data)
                dispatch(fetchAppointment(response.data.appointments))
            })    
        }
    }, [])
 
    return (
        <>
            <h1>Appointments</h1>
            <pre>{JSON.stringify(appointments, null, 2)}</pre>
            {
                appointments && appointments.map( (appointment) => {
                    return <Appointment key={appointment.appointmentId} appointment={appointment} />
                })    
            }
            
        </>
    ) 
}  

export default Appointments