function LoginButton() { 
    return (   
        <>
            <button>Login</button>
        </>
    )
}

export default LoginButton