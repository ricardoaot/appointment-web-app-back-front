const myAppointmentsData = [
    {
        "appointmentId": 1,
        "date": "2024-05-08T05:00:00.000Z",
        "time": "12:00:00",
        "status": "pending"
    },
    {
        "appointmentId": 2,
        "date": "2024-05-09T05:00:00.000Z",
        "time": "11:00:00",
        "status": "pending"
    }
]

export default myAppointmentsData