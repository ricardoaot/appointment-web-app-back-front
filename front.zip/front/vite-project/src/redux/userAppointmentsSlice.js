import { createSlice } from "@reduxjs/toolkit"

const userAppointmentsSlice = createSlice(
    {
        name: "userAppointments",
        initialState: 
        {
          // "userId": 1,
          // "name": "Ricardo Olivari",
          // "email": "ricardoaot@gmail.com",
          // "birthdate": "2024-05-15T05:00:00.000Z",
          // "nDni": "45107639",
          // "appointments": [
          //   {
          //     "appointmentId": 1,
          //     "date": "2024-05-08",
          //     "time": "12:00:00",
          //     "status": "pending"
          //   }
          // ]
        },
        reducers: {
            fetchAppointment: (state, action) => {
              //console.log(action.payload)
              //console.log(state)  
              return action.payload
            }
        }
    }
)
export default userAppointmentsSlice
export const { fetchAppointment } = userAppointmentsSlice.actions